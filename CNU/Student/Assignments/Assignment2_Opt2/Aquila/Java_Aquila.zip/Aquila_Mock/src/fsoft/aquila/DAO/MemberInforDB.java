package fsoft.aquila.DAO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;

import javax.servlet.http.HttpSession;
import fsoft.aquila.VO.MemberInfor;

public class MemberInforDB {

    private Collection members;

    private void init(HttpSession session) {
        members = new ArrayList();
        Random random = new Random();
        members.add(new MemberInfor(random.nextLong(), "David Roos", "Struts member", true));
        members.add(new MemberInfor(random.nextLong(), "Micheal Jackson", "Java member", true));
        members.add(new MemberInfor(random.nextLong(), "Bruce Lee", "Java2 member", false));
        members.add(new MemberInfor(random.nextLong(), "Tom Jones" ,"EJB member", true));
        members.add(new MemberInfor(random.nextLong(), "Mc Donald", "Jboss for beginners", false));
        members.add(new MemberInfor(random.nextLong(), "Lars Mars", "Using Myeclipse for cooking", true));
        members.add(new MemberInfor(random.nextLong(), "Mary Jane", "EJB or spending your weekends", true));

        session.setAttribute("memberDB", members);
    }

    /**
     * load data from db;
     * @param session
     */
    private void loadData(HttpSession session) {
        //      laliluna 04.10.2004 load members from db
        members = (Collection) session.getAttribute("memberDB");
        
        // laliluna 04.10.2004 db not yet initialized, so do it
        if (members == null)
            init(session);

    }
    
    /**
     * save data to DB ;-)
     * @param session
     */
    private void saveData(HttpSession session) {
        session.setAttribute("memberDB", members);
    }

    public long saveToDB(MemberInfor member, HttpSession session) {
        // laliluna 04.10.2004 load members from db
        loadData(session);

        // laliluna 04.10.2004 loop over collection and trying to find the member
        boolean memberExist = false;
        ArrayList membersNew = (ArrayList) members;
        int index = 0;
        for (Iterator iter = members.iterator(); iter.hasNext();) {
        	MemberInfor element = (MemberInfor) iter.next();
            // laliluna 04.10.2004 if member is found do an update
            if (element.getId() == member.getId()) {
            	membersNew.set(index, member);
                memberExist = true;
                break;
            }
            index++;
        }
        
        members = membersNew;
        
        // laliluna 04.10.2004 if member is not found, create a new member
        if (memberExist == false) {
            Random random = new Random();
            member.setId(random.nextLong());
            members.add(member);
        }

        // laliluna 04.10.2004 save to DB ;-)
        saveData(session);

        return member.getId();
    }

    public MemberInfor loadmemberById(long id, HttpSession session) {
        // laliluna 04.10.2004 load members from db
        loadData(session);
        // laliluna 04.10.2004 loop over all members and return member if found
        for (Iterator iter = members.iterator(); iter.hasNext();) {
        	MemberInfor element = (MemberInfor) iter.next();
            if (element.getId() == id) return (MemberInfor) element;
        }
        return null;
    }
    
    public void deletememberById(long id, HttpSession session){
    	// laliluna 04.10.2004 load members from db
        loadData(session);
        Collection membersNew = new ArrayList();
        // laliluna 04.10.2004 loop over all members and delete member if found
        for (Iterator iter = members.iterator(); iter.hasNext();) {
        	MemberInfor element = (MemberInfor) iter.next();
            if (element.getId() != id){
            	membersNew.add(element);
            }
        }
        // laliluna 04.10.2004 set the new members
        members = membersNew;
        
        // laliluna 04.10.2004 save to DB ;-)
        saveData(session);
    }

    public Collection getAllmembers(HttpSession session) {
        // laliluna 04.10.2004 load members from db
        loadData(session);
        return members;

    }
}
