
package fsoft.aquila.UI;


import org.apache.struts.action.ActionForm;

//import de.laliluna.tutorial.library.member;
import fsoft.aquila.VO.MemberInfor;

/** 
 * MyEclipse Struts
 * Creation date: 11-04-2004
 * 
 * XDoclet definition:
 * @struts:form name="memberEditForm"
 */
public class MemberInforEditForm extends ActionForm {

	MemberInfor member = new MemberInfor();
	
	public MemberInfor getMember() {
		return member;
	}
	public void setMember(MemberInfor member) {
		this.member = member;
	}
	public boolean equals(Object arg0) {
		return member.equals(arg0);
	}
	public String getName() {
		return member.getName();
	}
	public long getId() {
		return member.getId();
	}
	public String getEmail() {
		return member.getEmail();
	}
	public int hashCode() {
		return member.hashCode();
	}
	public boolean isAvailable() {
		return member.isAvailable();
	}
	public void setName(String name) {
		member.setName(name);
	}
	public void setAvailable(boolean available) {
		member.setAvailable(available);
	}
	public void setId(long id) {
		member.setId(id);
	}
	public void setEmail(String email) {
		member.setEmail(email);
	}
	public String toString() {
		return member.toString();
	}
}