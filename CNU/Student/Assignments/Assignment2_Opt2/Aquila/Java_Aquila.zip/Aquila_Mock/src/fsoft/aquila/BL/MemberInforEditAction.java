//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.0/xslt/JavaClass.xsl

package fsoft.aquila.BL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import fsoft.aquila.DAO.MemberInforDB;
import fsoft.aquila.UI.MemberInforEditForm;


/** 
 * MyEclipse Struts
 * Creation date: 11-04-2004
 * 
 * XDoclet definition:
 * @struts:action path="/memberEdit" name="memberEditForm" parameter="do" scope="request" validate="true"
 * @struts:action-forward name="/jsp/memberEdit.jsp" path="/jsp/memberEdit.jsp"
 */
public class MemberInforEditAction extends DispatchAction {

	/** 
	 * Method editmember
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward editmember(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		MemberInforEditForm memberInforEditForm = (MemberInforEditForm) form;
		
		/* lalinuna.de 04.11.2004
		 * get id of the member from request
		 */
		long id = Long.parseLong(request.getParameter("id"));
		
		/* lalinuna.de 04.11.2004
		 * init MemberInforDB class and get member id
		 */
		MemberInforDB memberInforDB = new MemberInforDB();
		memberInforEditForm.setMember(memberInforDB.loadmemberById(id, request.getSession()));
		
		return mapping.findForward("showEdit");
		
	}
	
	/** 
	 * Method deletemember
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward deletemember(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		MemberInforEditForm memberInforEditForm = (MemberInforEditForm) form;
		
		/* lalinuna.de 04.11.2004
		 * get id of the member from request
		 */
		long id = Long.parseLong(request.getParameter("id"));
		
		/* lalinuna.de 04.11.2004
		 * init MemberInforDB class and delete member by id
		 */
		MemberInforDB memberInforDB = new MemberInforDB();
		memberInforDB.deletememberById(id, request.getSession());
		
		return mapping.findForward("showList");
		
	}
	
	/** 
	 * Method addmember
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward addmember(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		MemberInforEditForm memberInforEditForm = (MemberInforEditForm) form;
		
		return mapping.findForward("showAdd");
		
	}
	
	/** 
	 * Method savemember
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward savemember(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		MemberInforEditForm memberInforEditForm = (MemberInforEditForm) form;
		
		/* lalinuna.de 04.11.2004
		 * init MemberInforDB class and get data by id
		 */
		MemberInforDB memberInforDB = new MemberInforDB();
		memberInforDB.saveToDB(memberInforEditForm.getMember(), request.getSession());
		
		return mapping.findForward("showList");
		
	}

}