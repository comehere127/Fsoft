package fsoft.aquila.VO;

public class MemberInfor {

    private long id;
    private String email;
    private String name;
    private boolean available;

    // Contructor
    public MemberInfor(){}
    //  Contructor to initial the properties
    public MemberInfor(long id, String name, String email, boolean available) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.available = available;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

}
